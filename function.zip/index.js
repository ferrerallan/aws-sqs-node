const axios = require('axios');



exports.handler =  async function(event, context) {
    console.log('Hello World from zip');

    const url = 'https://api.github.com/users/ferrerallan';
    await axios.get(url).then(response => {
        console.log(response.data);
    });


    return null;
}